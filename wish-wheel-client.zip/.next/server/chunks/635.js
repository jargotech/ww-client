"use strict";
exports.id = 635;
exports.ids = [635];
exports.modules = {

/***/ 6446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ APIURL)
/* harmony export */ });
const APIURL = 'http://3.139.226.194:3000/api' // export const APIURL = 'https://jsonplaceholder.typicode.com'
;


/***/ }),

/***/ 8635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CarService)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_apiConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6446);
/* harmony import */ var _utils_getAccessToken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9877);



class CarService {
    async getAllCollection() {
        return axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config_apiConfig__WEBPACK_IMPORTED_MODULE_1__/* .APIURL */ .z}/car/complete/car/detail`);
    }
    async getCarDetailById(carId) {
        return axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config_apiConfig__WEBPACK_IMPORTED_MODULE_1__/* .APIURL */ .z}/car/completeCarDetailById/${carId}`);
    }
    async getAllBrands() {
        return axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${_config_apiConfig__WEBPACK_IMPORTED_MODULE_1__/* .APIURL */ .z}/carMake`);
    }
    sellCar(payload) {
        return axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config_apiConfig__WEBPACK_IMPORTED_MODULE_1__/* .APIURL */ .z}/sellCar`, payload, {
            headers: {
                "x-access-token": (0,_utils_getAccessToken__WEBPACK_IMPORTED_MODULE_2__/* .xAccessToken */ .H)()
            }
        });
    }
    bookTrial(payload1) {
        return axios__WEBPACK_IMPORTED_MODULE_0___default().post(`${_config_apiConfig__WEBPACK_IMPORTED_MODULE_1__/* .APIURL */ .z}/trial`, payload1, {
            headers: {
                "x-access-token": (0,_utils_getAccessToken__WEBPACK_IMPORTED_MODULE_2__/* .xAccessToken */ .H)()
            }
        });
    }
}


/***/ }),

/***/ 9877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ xAccessToken),
/* harmony export */   "z": () => (/* binding */ userJwtData)
/* harmony export */ });
// export const xAccessToken = typeof window !== 'undefined' ? JSON.stringify(localStorage.getItem('jwt')) : null ;
// export const xAccessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxN2FkZjRiNGUwMzhmYjg5MjczZjZlMyIsImlhdCI6MTYzOTY3NjM1NiwiZXhwIjoxNjM5NzYyNzU2fQ.B4iW-0dhRyx-F5jtVNsVJq98shXb0-BX3nf_eJ_0PSs" ;
const xAccessToken = ()=>{
    let user = "";
    let token = "";
    if (localStorage) {
        user = localStorage.getItem("jwt") || "";
        if (user) {
            token = JSON.parse(user).accessToken;
        }
    }
    console.log(token);
    return token;
};
const userJwtData = ()=>{
    let user = "";
    let data = "";
    if (localStorage) {
        user = localStorage.getItem("jwt") || "";
        if (user) {
            data = JSON.parse(user).id;
        }
    }
    return data;
};


/***/ })

};
;